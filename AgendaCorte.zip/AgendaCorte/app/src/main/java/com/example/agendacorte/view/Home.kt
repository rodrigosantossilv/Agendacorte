package com.example.agendacorte.view

import android.content.Intent
import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.agendacorte.R
import com.example.agendacorte.databinding.ActivityHomeBinding
import com.example.agendacorte.model.Servicos
import com.example.agendacorte.model.Tela

class Home : AppCompatActivity() {

    private lateinit var binding: ActivityHomeBinding
    private val listaServicos: MutableList<Servicos> = mutableListOf()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityHomeBinding.inflate(layoutInflater)
        setContentView(binding.root)

        supportActionBar?.hide()
        val nome = intent.extras?.getString("nome")

        binding.bttratameto.setOnClickListener {
            val intent = Intent(this, Agendamento::class.java)
            intent.putExtra("nome", nome)
            startActivity(intent)
        }
        binding.btlava.setOnClickListener {
            val intent = Intent(this, Agendamento::class.java)
            intent.putExtra("nome", nome)
            startActivity(intent)
        }
        binding.btbarba.setOnClickListener {
            val intent = Intent(this, Agendamento::class.java)
            intent.putExtra("nome", nome)
            startActivity(intent)
        }
        binding.btcorte.setOnClickListener {
            val intent = Intent(this, Tela::class.java)
            intent.putExtra("nome", nome)
            startActivity(intent)
        }

        binding.btcosmeticos.setOnClickListener {
            val link = "https://www.drogariasaopaulo.com.br/minoxidil-5--locao-capilar-120ml-935201957/p"
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse(link))
            startActivity(intent)
        }

        // Restante dos listeners de botões...

        getServicos()
    }

    // Restante dos métodos (abrirAgendamento, abrirLinkExterno, etc.)

    private fun getServicos() {
        val servico1 = Servicos(R.drawable.img1, "Corte de Cabelo")
        listaServicos.add(servico1)

        // Adicione outros serviços à lista conforme necessário...
    }
}
