package com.example.agendacorte.model

class Servicos (
    val img: Int? = null,
    val nome: String? = null
)