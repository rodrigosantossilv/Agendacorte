package com.example.agendacorte.view

import android.graphics.Color
import android.os.Bundle
import android.util.Log
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import com.example.agendacorte.databinding.ActivityAgendamentoBinding
import com.google.android.material.snackbar.Snackbar
import com.google.firebase.firestore.FirebaseFirestore
import java.text.ParseException
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale
import java.util.UUID

class Agendamento : AppCompatActivity() {

    private lateinit var binding: ActivityAgendamentoBinding
    private var data: String = ""
    private var hora: String = ""
    private val db: FirebaseFirestore = FirebaseFirestore.getInstance()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityAgendamentoBinding.inflate(layoutInflater)
        setContentView(binding.root)

        supportActionBar?.hide()
        val nome = intent.extras?.getString("nome").toString()

        val datePicker = binding.datePicker
        datePicker.setOnDateChangedListener { _, year, monthOfYear, dayOfMonth ->

            val calendar = Calendar.getInstance()
            calendar.set(Calendar.YEAR, year)
            calendar.set(Calendar.MONTH, monthOfYear)
            calendar.set(Calendar.DAY_OF_YEAR, dayOfMonth)

            var dia = dayOfMonth.toString()

            if (dayOfMonth < 10) {
                dia = "0$dayOfMonth"
            }
            val mes: String = if (monthOfYear + 1 < 10) {
                "0${monthOfYear + 1}"
            } else {
                (monthOfYear + 1).toString()
            }

            data = "$dia / $mes / $year"
        }

        binding.timePicker.setOnTimeChangedListener { _, hourOfDay, minute ->

            val minuto: String = if (minute < 10) {
                "0$minute"
            } else {
                minute.toString()
            }
            hora = "$hourOfDay:$minuto"
        }

        binding.timePicker.setIs24HourView(true)

        binding.btAgendar.setOnClickListener {
            val barbeiro1 = binding.barbeiro1
            val barbeiro2 = binding.barbeiro2
            val barbeiro3 = binding.barbeiro3

            if (hora.isEmpty() || data.isEmpty()) {
                mensagem(it, "Preencha a data e o horário!", "#FF0000")
            } else if (!isHorarioValido(hora)) {
                mensagem(it, "Agenda Corte está fechado - horário de atendimento das 08:00 às 19:00!", "#FF0000")
            } else {
                when {
                    barbeiro1.isChecked -> salvarAgendamento(it, nome, "Roberto dos Santos", data, hora)
                    barbeiro2.isChecked -> salvarAgendamento(it, nome, "Cristiano de Jesus", data, hora)
                    barbeiro3.isChecked -> salvarAgendamento(it, nome, "Amanda Matos", data, hora)
                    else -> mensagem(it, "Escolha um Barbeiro!", "#FF0000")
                }
            }
        }
    }

    private fun mensagem(view: View, mensagem: String, cor: String) {
        val snackbar = Snackbar.make(view, mensagem, Snackbar.LENGTH_SHORT)
        snackbar.setBackgroundTint(Color.parseColor(cor))
        snackbar.setTextColor(Color.parseColor("#FFFFFF"))
        snackbar.show()
    }

    private fun salvarAgendamento(view: View, cliente: String, barbeiro: String, data: String, hora: String) {
        val appointmentId = UUID.randomUUID().toString()

        val dadosUsuario = hashMapOf(
            "cliente" to cliente,
            "barbeiro" to barbeiro,
            "data" to data,
            "hora" to hora
        )

        db.collection("agendados").document(appointmentId).set(dadosUsuario)
            .addOnCompleteListener {
                mensagem(view, "Agendamento realizado com sucesso!", "#FF03DAC5")
            }
            .addOnFailureListener { e ->
                Log.e("Agendamento", "Erro ao salvar o agendamento.", e)
                mensagem(view, "Erro ao salvar o agendamento. Tente novamente!", "#FF0000")
            }
    }

    private fun isHorarioValido(hora: String): Boolean {
        val formato = SimpleDateFormat("HH:mm", Locale.getDefault())
        val horarioAbertura = formato.parse("08:00")
        val horarioFechamento = formato.parse("19:00")

        try {
            val horarioSelecionado = formato.parse(hora)
            return horarioSelecionado in horarioAbertura..horarioFechamento
        } catch (e: ParseException) {
            e.printStackTrace()
        }
        return false
    }
}
