package com.example.agendacorte

import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.view.View
import com.example.agendacorte.databinding.ActivityMainBinding
import com.example.agendacorte.view.Home
import com.google.android.material.snackbar.Snackbar
import com.google.firebase.auth.FirebaseAuth
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var firebaseAuth: FirebaseAuth

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        supportActionBar?.hide()

        firebaseAuth = FirebaseAuth.getInstance()

        binding.btLogin.setOnClickListener {
            val email = binding.editEmail.text.toString().trim()
            val senha = binding.editSenha.text.toString().trim()

            when {
                email.isEmpty() -> mensagem(it, "Coloque seu email!")
                senha.isEmpty() -> mensagem(it, "Coloque sua senha!")
                senha.length <= 5 -> mensagem(it, "A senha precisa ter pelo menos 6 caracteres!")
                else -> autenticarUsuario(email, senha)
            }
        }
    }

    private fun mensagem(view: View, mensagem: String) {
        val snackbar = Snackbar.make(view, mensagem, Snackbar.LENGTH_SHORT)
        snackbar.setBackgroundTint(Color.parseColor("#FF0080"))
        snackbar.setTextColor(Color.parseColor("#FFFFFF"))
        snackbar.show()
    }

    private fun autenticarUsuario(email: String, senha: String) {
        firebaseAuth.signInWithEmailAndPassword(email, senha)
            .addOnCompleteListener(this) { task ->
                if (task.isSuccessful) {
                    // Autenticação bem-sucedida, navegue para a tela inicial
                    navegarPraHome(email)
                } else {
                    // Se a autenticação falhar, exiba uma mensagem de erro
                    mensagem(binding.root, "Falha na autenticação. Verifique suas credenciais.")
                }
            }
    }

    private fun navegarPraHome(nome: String) {
        val intent = Intent(this, Home::class.java)
        intent.putExtra("nome", nome)
        startActivity(intent)
    }

}
